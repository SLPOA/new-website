---
date: 2016-04-20T10:21:05+02:00
title: index
type: index
---

# gallery

Fancy box is used to display image gallery with this shortcode:
{{< highlight html >}}
{{</* gallery image="space1.jpg" */>}}
{{</* gallery image="space2.jpg" addclass="hidden" */>}}
{{< /highlight >}}

{{< gallery image="space1.jpg" >}}
{{< gallery image="space2.jpg" addclass="hidden" >}}

# pygments

Pygments is used to do syntax highlighting.
