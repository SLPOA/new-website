---
date: 2016-04-20T10:13:26+02:00
title: installation
menu:
  main:
    parent: Getting started
    identifier: /getting-started/installation
    weight: 10
---

# installation steps

Here how to install the tool.
